package com.example.circuit_breaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
